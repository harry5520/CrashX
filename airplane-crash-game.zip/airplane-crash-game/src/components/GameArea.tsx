import React from 'react';
import { useGame } from '../contexts/GameContext';
import { Airplane } from './Airplane';

export const GameArea: React.FC = () => {
  const { gameState, cashOut } = useGame();

  const getMultiplierColor = () => {
    if (gameState.hasCrashed) return 'text-red-500';
    if (gameState.currentMultiplier > 2) return 'text-green-400';
    if (gameState.currentMultiplier > 1.5) return 'text-yellow-400';
    return 'text-white';
  };

  const getStatusText = () => {
    if (gameState.hasCrashed) return 'CRASHED!';
    if (gameState.playerCashedOut) return `CASHED OUT AT ${gameState.playerCashOutMultiplier?.toFixed(2)}x`;
    if (gameState.isPlayerBetting && !gameState.playerCashedOut) return 'BETTING...';
    if (gameState.isGameRunning) return 'FLYING...';
    return 'WAITING FOR NEXT ROUND...';
  };

  const getStatusColor = () => {
    if (gameState.hasCrashed) return 'text-red-500';
    if (gameState.playerCashedOut) return 'text-green-400';
    if (gameState.isPlayerBetting) return 'text-yellow-400';
    return 'text-gray-400';
  };

  return (
    <div className="flex-1 flex flex-col items-center justify-center relative overflow-hidden">
      {/* Background Grid */}
      <div className="absolute inset-0 opacity-10">
        <div 
          className="w-full h-full"
          style={{
            backgroundImage: 'linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)',
            backgroundSize: '20px 20px'
          }}
        />
      </div>

      {/* Airplane */}
      <div className="absolute top-20 left-0 w-full h-full">
        <Airplane 
          isFlying={gameState.isGameRunning} 
          hasCrashed={gameState.hasCrashed}
          progress={gameState.currentMultiplier}
        />
      </div>

      {/* Main Multiplier Display */}
      <div className="text-center z-10">
        <div className={`text-6xl md:text-8xl font-bold mb-4 transition-all duration-300 ${getMultiplierColor()}`}>
          {gameState.currentMultiplier.toFixed(2)}x
        </div>
        
        {/* Status Text */}
        <div className={`text-lg md:text-xl font-semibold mb-6 ${getStatusColor()}`}>
          {getStatusText()}
        </div>

        {/* Cash Out Button */}
        {gameState.isPlayerBetting && !gameState.playerCashedOut && !gameState.hasCrashed && (
          <button
            onClick={cashOut}
            className="bg-green-500 hover:bg-green-600 text-white text-xl font-bold py-4 px-8 rounded-lg transition-all duration-200 transform hover:scale-105 shadow-lg"
          >
            CASH OUT
            <div className="text-sm opacity-80">
              ₹{(gameState.currentBet * gameState.currentMultiplier).toFixed(2)}
            </div>
          </button>
        )}
      </div>

      {/* Crash Effect */}
      {gameState.hasCrashed && (
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute inset-0 bg-red-500 opacity-20 animate-pulse" />
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
            <div className="text-red-500 text-4xl font-bold animate-bounce">
              💥 CRASHED AT {gameState.crashMultiplier?.toFixed(2)}x 💥
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
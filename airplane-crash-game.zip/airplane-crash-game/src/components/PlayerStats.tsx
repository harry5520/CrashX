import React from 'react';
import { useGame } from '../contexts/GameContext';

export const PlayerStats: React.FC = () => {
  const { gameState } = useGame();

  return (
    <div className="bg-gray-800 border-t border-gray-700 p-4">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
        <div className="bg-gray-700 rounded-lg p-3">
          <div className="text-gray-400 text-xs uppercase tracking-wide mb-1">
            Players
          </div>
          <div className="text-white text-lg font-bold">
            {gameState.totalPlayers.toLocaleString()}
          </div>
        </div>
        
        <div className="bg-gray-700 rounded-lg p-3">
          <div className="text-gray-400 text-xs uppercase tracking-wide mb-1">
            Total Bets
          </div>
          <div className="text-white text-lg font-bold">
            {gameState.totalBets.toLocaleString()}
          </div>
        </div>
        
        <div className="bg-gray-700 rounded-lg p-3">
          <div className="text-gray-400 text-xs uppercase tracking-wide mb-1">
            Total Wins
          </div>
          <div className="text-green-400 text-lg font-bold">
            ₹{gameState.totalWinAmount.toLocaleString()}
          </div>
        </div>
        
        <div className="bg-gray-700 rounded-lg p-3">
          <div className="text-gray-400 text-xs uppercase tracking-wide mb-1">
            Your Balance
          </div>
          <div className="text-yellow-400 text-lg font-bold">
            ₹{gameState.playerBalance.toFixed(2)}
          </div>
        </div>
      </div>
    </div>
  );
};
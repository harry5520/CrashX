import React from 'react';
import { useGame } from '../contexts/GameContext';

export const HistoryBar: React.FC = () => {
  const { gameState } = useGame();

  const getMultiplierColor = (multiplier: number) => {
    if (multiplier >= 10) return 'bg-purple-600 text-white';
    if (multiplier >= 5) return 'bg-green-600 text-white';
    if (multiplier >= 2) return 'bg-green-500 text-white';
    if (multiplier >= 1.5) return 'bg-yellow-500 text-black';
    return 'bg-red-500 text-white';
  };

  return (
    <div className="bg-gray-800 border-b border-gray-700 p-3">
      <div className="flex items-center space-x-2 overflow-x-auto">
        <span className="text-gray-400 text-sm font-medium whitespace-nowrap mr-2">
          History:
        </span>
        <div className="flex space-x-2">
          {gameState.gameHistory.map((multiplier, index) => (
            <div
              key={index}
              className={`
                px-3 py-1 rounded-full text-sm font-bold whitespace-nowrap
                ${getMultiplierColor(multiplier)}
                ${index === 0 ? 'ring-2 ring-white ring-opacity-50' : ''}
              `}
            >
              {multiplier.toFixed(2)}x
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
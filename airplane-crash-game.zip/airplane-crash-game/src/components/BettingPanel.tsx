import React from 'react';
import { useGame } from '../contexts/GameContext';

export const BettingPanel: React.FC = () => {
  const { gameState, placeBet, setBetAmount } = useGame();

  const presetAmounts = [10, 100, 500, 1000];

  const handleBetAmountChange = (change: number) => {
    const newAmount = Math.max(1, gameState.betAmount + change);
    setBetAmount(newAmount);
  };

  const handlePresetAmount = (amount: number) => {
    setBetAmount(amount);
  };

  const handlePlaceBet = () => {
    if (gameState.playerBalance >= gameState.betAmount && !gameState.isGameRunning) {
      placeBet(gameState.betAmount);
    }
  };

  const canPlaceBet = () => {
    return !gameState.isGameRunning && 
           !gameState.isPlayerBetting && 
           gameState.playerBalance >= gameState.betAmount &&
           !gameState.hasCrashed;
  };

  return (
    <div className="bg-gray-800 border-t border-gray-700 p-4">
      {/* Bet Amount Controls */}
      <div className="mb-4">
        <div className="text-gray-400 text-sm font-medium mb-2">Bet Amount</div>
        
        {/* Amount Input with Controls */}
        <div className="flex items-center space-x-2 mb-3">
          <button
            onClick={() => handleBetAmountChange(-10)}
            disabled={gameState.betAmount <= 10}
            className="bg-gray-700 hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold w-10 h-10 rounded-lg transition-colors"
          >
            -
          </button>
          
          <div className="flex-1 bg-gray-700 rounded-lg p-3 text-center">
            <div className="text-white text-lg font-bold">
              ₹{gameState.betAmount.toFixed(2)}
            </div>
          </div>
          
          <button
            onClick={() => handleBetAmountChange(10)}
            disabled={gameState.betAmount + 10 > gameState.playerBalance}
            className="bg-gray-700 hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold w-10 h-10 rounded-lg transition-colors"
          >
            +
          </button>
        </div>
        
        {/* Preset Amount Buttons */}
        <div className="grid grid-cols-4 gap-2 mb-4">
          {presetAmounts.map((amount) => (
            <button
              key={amount}
              onClick={() => handlePresetAmount(amount)}
              disabled={amount > gameState.playerBalance}
              className={`
                py-2 px-3 rounded-lg font-medium transition-all duration-200
                ${
                  gameState.betAmount === amount
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-700 hover:bg-gray-600 text-gray-300'
                }
                disabled:opacity-50 disabled:cursor-not-allowed
              `}
            >
              ₹{amount}
            </button>
          ))}
        </div>
      </div>

      {/* Betting Actions */}
      <div className="space-y-3">
        {/* Main Bet Button */}
        <button
          onClick={handlePlaceBet}
          disabled={!canPlaceBet()}
          className={`
            w-full py-4 rounded-lg font-bold text-xl transition-all duration-200 transform
            ${
              canPlaceBet()
                ? 'bg-green-600 hover:bg-green-700 hover:scale-105 text-white shadow-lg'
                : 'bg-gray-600 cursor-not-allowed text-gray-400'
            }
          `}
        >
          {gameState.isPlayerBetting ? 'BET PLACED' : 
           gameState.isGameRunning ? 'GAME IN PROGRESS' :
           gameState.hasCrashed ? 'GAME CRASHED' :
           'PLACE BET'}
        </button>
        
        {/* Current Bet Info */}
        {gameState.isPlayerBetting && (
          <div className="bg-yellow-900 border border-yellow-600 rounded-lg p-3">
            <div className="text-yellow-400 text-sm font-medium">
              Active Bet: ₹{gameState.currentBet.toFixed(2)}
            </div>
            <div className="text-yellow-300 text-xs">
              Potential Win: ₹{(gameState.currentBet * gameState.currentMultiplier).toFixed(2)}
            </div>
          </div>
        )}
        
        {/* Auto Bet Controls (placeholder for future feature) */}
        <div className="grid grid-cols-2 gap-2">
          <button className="bg-gray-700 hover:bg-gray-600 text-gray-400 py-2 rounded-lg font-medium transition-colors cursor-not-allowed opacity-50">
            Auto Bet (Soon)
          </button>
          <button className="bg-gray-700 hover:bg-gray-600 text-gray-400 py-2 rounded-lg font-medium transition-colors cursor-not-allowed opacity-50">
            Auto Cash Out (Soon)
          </button>
        </div>
      </div>
      
      {/* Balance Warning */}
      {gameState.playerBalance < gameState.betAmount && (
        <div className="mt-3 text-red-400 text-sm text-center">
          Insufficient balance for this bet amount
        </div>
      )}
    </div>
  );
};
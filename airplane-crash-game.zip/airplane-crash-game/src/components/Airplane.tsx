import React from 'react';

interface AirplaneProps {
  isFlying: boolean;
  hasCrashed: boolean;
  progress: number;
}

export const Airplane: React.FC<AirplaneProps> = ({ isFlying, hasCrashed, progress }) => {
  const getAirplanePosition = () => {
    if (!isFlying) return { left: '5%', top: '80%' };
    
    // Calculate position based on multiplier progress
    const leftPercent = Math.min((progress - 1) * 50 + 5, 85); // Move from 5% to 85%
    const topPercent = Math.max(80 - (progress - 1) * 40, 20); // Move from 80% to 20%
    
    return {
      left: `${leftPercent}%`,
      top: `${topPercent}%`
    };
  };

  const position = getAirplanePosition();

  return (
    <div
      className={`absolute transition-all duration-100 ease-linear transform ${
        hasCrashed ? 'rotate-45 animate-pulse' : isFlying ? 'rotate-12' : 'rotate-0'
      }`}
      style={{
        left: position.left,
        top: position.top,
        transform: `translate(-50%, -50%) ${hasCrashed ? 'rotate(45deg)' : isFlying ? 'rotate(12deg)' : 'rotate(0deg)'}`
      }}
    >
      {/* Airplane SVG */}
      <svg 
        width="60" 
        height="60" 
        viewBox="0 0 100 100" 
        className={`${hasCrashed ? 'text-red-500' : 'text-red-400'} drop-shadow-lg`}
      >
        <g fill="currentColor">
          {/* Airplane body */}
          <ellipse cx="50" cy="50" rx="35" ry="8" transform="rotate(-15 50 50)" />
          
          {/* Wings */}
          <ellipse cx="45" cy="45" rx="25" ry="4" transform="rotate(-15 45 45)" />
          <ellipse cx="55" cy="55" rx="15" ry="3" transform="rotate(-15 55 55)" />
          
          {/* Tail */}
          <ellipse cx="25" cy="60" rx="8" ry="3" transform="rotate(-15 25 60)" />
          <ellipse cx="22" cy="55" rx="6" ry="2" transform="rotate(-15 22 55)" />
        </g>
      </svg>
      
      {/* Trail effect when flying */}
      {isFlying && !hasCrashed && (
        <div className="absolute right-full top-1/2 transform -translate-y-1/2">
          <div className="flex space-x-1">
            {[...Array(5)].map((_, i) => (
              <div
                key={i}
                className="w-2 h-2 bg-orange-400 rounded-full opacity-60 animate-pulse"
                style={{
                  animationDelay: `${i * 0.1}s`,
                  animationDuration: '0.5s'
                }}
              />
            ))}
          </div>
        </div>
      )}
      
      {/* Explosion effect when crashed */}
      {hasCrashed && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-4xl animate-ping">💥</div>
        </div>
      )}
    </div>
  );
};
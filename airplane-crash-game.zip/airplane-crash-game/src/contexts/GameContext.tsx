import React, { createContext, useContext, useState, useEffect, useRef } from 'react';

interface GameState {
  isGameRunning: boolean;
  currentMultiplier: number;
  crashMultiplier: number | null;
  hasCrashed: boolean;
  gameHistory: number[];
  playerBalance: number;
  currentBet: number;
  totalPlayers: number;
  totalBets: number;
  totalWinAmount: number;
  betAmount: number;
  isPlayerBetting: boolean;
  playerCashedOut: boolean;
  playerCashOutMultiplier: number | null;
}

interface GameContextType {
  gameState: GameState;
  startGame: () => void;
  placeBet: (amount: number) => void;
  cashOut: () => void;
  setBetAmount: (amount: number) => void;
}

const GameContext = createContext<GameContextType | undefined>(undefined);

export const useGame = () => {
  const context = useContext(GameContext);
  if (!context) {
    throw new Error('useGame must be used within a GameProvider');
  }
  return context;
};

export const GameProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [gameState, setGameState] = useState<GameState>({
    isGameRunning: false,
    currentMultiplier: 1.0,
    crashMultiplier: null,
    hasCrashed: false,
    gameHistory: [2.48, 1.57, 3.22, 1.89, 4.15, 1.23, 2.91, 1.67, 3.45, 2.12],
    playerBalance: 1000,
    currentBet: 0,
    totalPlayers: 2838,
    totalBets: 2840,
    totalWinAmount: 125000,
    betAmount: 10,
    isPlayerBetting: false,
    playerCashedOut: false,
    playerCashOutMultiplier: null,
  });

  const gameIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const gameTimeRef = useRef(0);

  const generateCrashMultiplier = () => {
    // Simple crash multiplier generation (in real app, this would be server-side)
    const random = Math.random();
    if (random < 0.2) return 1 + Math.random() * 0.5; // 20% chance of 1.0-1.5x
    if (random < 0.5) return 1.5 + Math.random() * 1; // 30% chance of 1.5-2.5x
    if (random < 0.8) return 2.5 + Math.random() * 2; // 30% chance of 2.5-4.5x
    return 4.5 + Math.random() * 10; // 20% chance of 4.5-14.5x
  };

  const startGame = () => {
    if (gameState.isGameRunning) return;

    const crashMultiplier = generateCrashMultiplier();
    gameTimeRef.current = 0;

    setGameState(prev => ({
      ...prev,
      isGameRunning: true,
      currentMultiplier: 1.0,
      crashMultiplier,
      hasCrashed: false,
      playerCashedOut: false,
      playerCashOutMultiplier: null,
    }));

    // Start game loop
    gameIntervalRef.current = setInterval(() => {
      gameTimeRef.current += 50;
      const progress = gameTimeRef.current / 1000; // seconds
      const newMultiplier = 1 + progress * 0.5; // Increase by 0.5x per second

      setGameState(prev => {
        if (newMultiplier >= crashMultiplier) {
          // Game crashed
          if (gameIntervalRef.current) {
            clearInterval(gameIntervalRef.current);
            gameIntervalRef.current = null;
          }

          // Update history
          const newHistory = [crashMultiplier, ...prev.gameHistory.slice(0, 9)];

          // Update player balance if they didn't cash out
          let newBalance = prev.playerBalance;
          if (prev.isPlayerBetting && !prev.playerCashedOut) {
            // Player lost their bet
            newBalance = prev.playerBalance; // Already subtracted when bet was placed
          }

          return {
            ...prev,
            isGameRunning: false,
            currentMultiplier: crashMultiplier,
            hasCrashed: true,
            gameHistory: newHistory,
            playerBalance: newBalance,
            isPlayerBetting: false,
            totalBets: prev.totalBets + Math.floor(Math.random() * 10),
          };
        }

        return {
          ...prev,
          currentMultiplier: newMultiplier,
        };
      });
    }, 50);
  };

  const placeBet = (amount: number) => {
    if (gameState.isGameRunning || gameState.playerBalance < amount) return;

    setGameState(prev => ({
      ...prev,
      currentBet: amount,
      playerBalance: prev.playerBalance - amount,
      isPlayerBetting: true,
      playerCashedOut: false,
      playerCashOutMultiplier: null,
    }));
  };

  const cashOut = () => {
    if (!gameState.isPlayerBetting || gameState.playerCashedOut || gameState.hasCrashed) return;

    const winAmount = gameState.currentBet * gameState.currentMultiplier;
    
    setGameState(prev => ({
      ...prev,
      playerBalance: prev.playerBalance + winAmount,
      playerCashedOut: true,
      playerCashOutMultiplier: prev.currentMultiplier,
      isPlayerBetting: false,
      totalWinAmount: prev.totalWinAmount + winAmount,
    }));
  };

  const setBetAmount = (amount: number) => {
    setGameState(prev => ({
      ...prev,
      betAmount: amount,
    }));
  };

  // Auto-start games with delay
  useEffect(() => {
    if (!gameState.isGameRunning && !gameState.hasCrashed) {
      const timeout = setTimeout(() => {
        startGame();
      }, 2000);
      return () => clearTimeout(timeout);
    }
  }, [gameState.isGameRunning, gameState.hasCrashed]);

  // Auto-restart after crash
  useEffect(() => {
    if (gameState.hasCrashed) {
      const timeout = setTimeout(() => {
        setGameState(prev => ({ ...prev, hasCrashed: false }));
      }, 3000);
      return () => clearTimeout(timeout);
    }
  }, [gameState.hasCrashed]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (gameIntervalRef.current) {
        clearInterval(gameIntervalRef.current);
      }
    };
  }, []);

  return (
    <GameContext.Provider value={{
      gameState,
      startGame,
      placeBet,
      cashOut,
      setBetAmount,
    }}>
      {children}
    </GameContext.Provider>
  );
};
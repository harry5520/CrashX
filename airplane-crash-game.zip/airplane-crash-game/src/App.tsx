import { useState, useEffect, useRef } from 'react';
import { GameArea } from './components/GameArea';
import { HistoryBar } from './components/HistoryBar';
import { BettingPanel } from './components/BettingPanel';
import { PlayerStats } from './components/PlayerStats';
import { GameProvider } from './contexts/GameContext';
import './App.css';

function App() {
  return (
    <GameProvider>
      <div className="min-h-screen bg-gray-900 text-white flex flex-col">
        {/* History Bar */}
        <HistoryBar />
        
        {/* Main Game Area */}
        <div className="flex-1 flex flex-col">
          <GameArea />
          
          {/* Player Stats */}
          <PlayerStats />
          
          {/* Betting Panel */}
          <BettingPanel />
        </div>
      </div>
    </GameProvider>
  );
}

export default App;